# TEMBAK FOLLOWERS PRO

Starter project Android Kotlin + Jetpack Compose, tema hitam dan biru neon.

## Fitur saat ini
- Login owner demo
- Dashboard
- Panel analitik dengan input statistik manual
- Ide konten
- Navigasi profil dan logout
- Kartu platform TikTok, Instagram, YouTube

Aplikasi ini hanya untuk analitik dan pertumbuhan organik. Tidak ada bot, followers palsu,
spam, pengumpulan password platform, atau otomatisasi engagement.

## Login demo
- Username: `owner`
- Password: `owner123`

PENTING: kredensial demo ditanam di aplikasi dan TIDAK aman untuk produksi.
Sebelum dipublikasikan, ganti dengan autentikasi backend, simpan password dalam bentuk hash,
gunakan HTTPS, dan atur peran admin di server.

## Cara build APK
1. Buka folder proyek ini dengan Android Studio versi terbaru.
2. Tunggu Gradle Sync selesai (butuh koneksi internet untuk mengunduh dependensi).
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Proyek ini adalah source code; APK belum dikompilasi di sini.
