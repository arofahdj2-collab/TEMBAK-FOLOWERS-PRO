package com.tembakfollowerspro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF111C2E)
private val Neon = Color(0xFF00B7FF)
private val Muted = Color(0xFF9CB0C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var loggedIn by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Dashboard") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Neon,
        onBackground = Color.White, onSurface = Color.White
    )) {
        if (!loggedIn) {
            LoginScreen(username, { username = it }, password, { password = it }) {
                // Demo owner login only. Replace with secure backend authentication before release.
                if (username == "owner" && password == "owner123") loggedIn = true
            }
        } else {
            Dashboard(page, { page = it }) { loggedIn = false }
        }
    }
}

@Composable
fun LoginScreen(user: String, onUser: (String) -> Unit, pass: String,
                onPass: (String) -> Unit, onLogin: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Bolt, null, tint = Neon, modifier = Modifier.size(58.dp))
            Text("TEMBAK FOLLOWERS", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("PRO  •  CREATOR TOOLKIT", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("OWNER LOGIN", color = Neon, fontWeight = FontWeight.Bold)
                    OutlinedTextField(user, onUser, label = { Text("Username") }, singleLine = true)
                    OutlinedTextField(pass, onPass, label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(), singleLine = true)
                    Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("MASUK OWNER") }
                    Text("Demo: owner / owner123", color = Muted, fontSize = 12.sp)
                }
            }
            Text("Gunakan untuk analitik dan pengembangan konten yang organik.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun Dashboard(page: String, onPage: (String) -> Unit, onLogout: () -> Unit) {
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Panel) {
            listOf("Dashboard", "Analitik", "Ide Konten", "Profil").forEach { item ->
                NavigationBarItem(selected = page == item, onClick = { onPage(item) },
                    icon = { Icon(when(item) {
                        "Dashboard" -> Icons.Default.Home
                        "Analitik" -> Icons.Default.BarChart
                        "Ide Konten" -> Icons.Default.Lightbulb
                        else -> Icons.Default.Person
                    }, null) }, label = { Text(item, fontSize = 10.sp) })
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TEMBAK FOLLOWERS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text("CREATOR GROWTH CENTER", color = Neon, fontSize = 10.sp)
                }
                Icon(Icons.Default.Bolt, null, tint = Neon, modifier = Modifier.size(32.dp))
            }
            when(page) {
                "Dashboard" -> {
                    Text("Halo, Owner 👋", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Pantau perkembangan akunmu secara aman.", color = Muted)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("Followers", "—", "Masukkan data sendiri", Modifier.weight(1f))
                        StatCard("Engagement", "—", "Butuh data analitik", Modifier.weight(1f))
                    }
                    SectionCard("Platform") {
                        PlatformRow("TikTok", "Analisis profil & performa konten")
                        PlatformRow("Instagram", "Pantau insight akun")
                        PlatformRow("YouTube", "Evaluasi channel dan video")
                    }
                    SectionCard("Aksi cepat") {
                        ActionRow("Analisis konten", "Lihat metrik dan tren")
                        ActionRow("Rencana posting", "Susun jadwal konten")
                        ActionRow("Ide konten", "Cari inspirasi video baru")
                    }
                    Text("Catatan: aplikasi ini tidak mengirim followers palsu, bot, atau likes otomatis.", color = Muted, fontSize = 11.sp)
                }
                "Analitik" -> {
                    Text("Analitik akun", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    SectionCard("Input statistik manual") {
                        Text("Masukkan angka dari dashboard resmi platform untuk membandingkan perkembangan.", color = Muted)
                        var followers by remember { mutableStateOf("") }
                        var views by remember { mutableStateOf("") }
                        OutlinedTextField(followers, { followers = it }, label = { Text("Jumlah followers") })
                        OutlinedTextField(views, { views = it }, label = { Text("Jumlah tayangan") })
                        Text("Followers: ${followers.ifBlank { "—" }}   •   Tayangan: ${views.ifBlank { "—" }}", color = Neon)
                    }
                }
                "Ide Konten" -> {
                    Text("Studio ide konten", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    listOf("Buat video perkenalan 15 detik", "Tampilkan proses di balik layar", "Jawab pertanyaan dari komentar", "Buat seri tips singkat", "Bandingkan sebelum dan sesudah").forEachIndexed { i, s ->
                        SectionCard("Ide ${i+1}") { Text(s, color = Color.White) }
                    }
                }
                else -> {
                    Text("Profil Owner", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    SectionCard("Akun demo") {
                        Text("Username: owner", color = Color.White)
                        Text("Mode: Administrator lokal (demo)", color = Muted)
                        Button(onClick = onLogout) { Text("Keluar") }
                    }
                    Text("Untuk rilis publik, login harus dipindahkan ke server dengan password yang di-hash dan pengelolaan sesi yang aman.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, hint: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Neon, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(hint, color = Muted, fontSize = 10.sp)
        }
    }
}
@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Neon, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
@Composable
fun PlatformRow(name: String, detail: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.PlayCircle, null, tint = Neon)
        Spacer(Modifier.width(10.dp))
        Column { Text(name, fontWeight = FontWeight.Bold); Text(detail, color = Muted, fontSize = 11.sp) }
    }
}
@Composable
fun ActionRow(title: String, detail: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.ChevronRight, null, tint = Neon)
        Column { Text(title, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 11.sp) }
    }
}
